export { default as AnimatedSprite } from './AnimatedSprite';
