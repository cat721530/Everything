export { default as settings } from './settings';
export { default as isMobile } from 'ismobilejs';
