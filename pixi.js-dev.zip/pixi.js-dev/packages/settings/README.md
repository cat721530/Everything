# @pixi/settings

## Installation

```bash
npm install @pixi/settings
```

## Usage

```js
import * as settings from '@pixi/settings';
```