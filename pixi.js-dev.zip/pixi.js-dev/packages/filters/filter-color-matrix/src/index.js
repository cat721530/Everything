export { default as ColorMatrixFilter } from './ColorMatrixFilter';
