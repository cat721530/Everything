export { default as FXAAFilter } from './FXAAFilter';
