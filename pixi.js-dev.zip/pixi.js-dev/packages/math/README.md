# @pixi/math

## Installation

```bash
npm install @pixi/math
```

## Usage

```js
import * as math from '@pixi/math';
```