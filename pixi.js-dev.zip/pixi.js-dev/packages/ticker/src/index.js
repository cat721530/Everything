import './settings';

export { default as Ticker } from './Ticker';
export { default as TickerPlugin } from './TickerPlugin';
export * from './const';
